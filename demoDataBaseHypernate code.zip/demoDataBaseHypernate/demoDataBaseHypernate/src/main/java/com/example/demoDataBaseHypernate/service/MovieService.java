package com.example.demoDataBaseHypernate.service;

import com.example.demoDataBaseHypernate.models.Movies;
import com.example.demoDataBaseHypernate.repository.MoviesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {

    @Autowired
    MoviesRepository moviesRepository;

    public void addMoives(Movies movie)
    {
        moviesRepository.save(movie);
    }

    public List<Movies>  getAllMovies()
    {
        return moviesRepository.findAll();
    }
}
