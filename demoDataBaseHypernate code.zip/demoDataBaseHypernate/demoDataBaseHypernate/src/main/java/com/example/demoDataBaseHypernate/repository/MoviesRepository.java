package com.example.demoDataBaseHypernate.repository;


import com.example.demoDataBaseHypernate.models.Movies;
import org.springframework.data.jpa.repository.JpaRepository;



public interface MoviesRepository extends JpaRepository<Movies,String> {


}
