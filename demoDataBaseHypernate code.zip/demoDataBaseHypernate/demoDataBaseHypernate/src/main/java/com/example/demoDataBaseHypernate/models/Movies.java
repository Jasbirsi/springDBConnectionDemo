package com.example.demoDataBaseHypernate.models;

import org.springframework.stereotype.Component;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movie_db")   // this will create a table in our data base with name movie_db,
                            // and its colum will be the attributes of the class
public class Movies {

    @Id  //it will act as primary key (name)
    private String name;
    //if we want to change the name of colum of the tabe were the time duration values are storign then

    @Column(name = "movie_length")
    private int timeDuration;
     private double ratings;

    public Movies(String name, int timeDuration, double ratings) {
        this.name = name;
        this.timeDuration = timeDuration;
        this.ratings = ratings;
    }
    Movies()
    {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTimeDuration() {
        return timeDuration;
    }

    public void setTimeDuration(int timeDuration) {
        this.timeDuration = timeDuration;
    }

    public double getRatings() {
        return ratings;
    }

    public void setRatings(double ratings) {
        this.ratings = ratings;
    }
}
