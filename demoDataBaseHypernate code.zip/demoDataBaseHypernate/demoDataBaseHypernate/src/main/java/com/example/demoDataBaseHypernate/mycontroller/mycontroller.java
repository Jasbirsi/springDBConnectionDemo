package com.example.demoDataBaseHypernate.mycontroller;

import com.example.demoDataBaseHypernate.models.Movies;
import com.example.demoDataBaseHypernate.repository.MoviesRepository;
import com.example.demoDataBaseHypernate.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
public class mycontroller {

    @Autowired
    MovieService movieService;
    @PostMapping("/add-movie")
    public ResponseEntity<String> addMovie( @RequestBody Movies body)
    {
        movieService.addMoives(body);
        return new ResponseEntity<>("Success", HttpStatus.ACCEPTED);
    }

    @GetMapping ("/get-movies")
    public ResponseEntity<List<Movies>> getallmovies ()
    {
         List<Movies> movies=new ArrayList<>(movieService.getAllMovies());
        return  new ResponseEntity<>(movies,HttpStatus.ACCEPTED);
    }

}
